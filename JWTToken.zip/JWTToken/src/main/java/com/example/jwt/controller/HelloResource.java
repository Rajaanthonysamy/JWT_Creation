package com.example.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt.model.AuthenticationRequest;
import com.example.jwt.model.AuthenticationResponse;
import com.example.jwt.user.MyUserDteatilService;
import com.example.jwt.util.JWTUtil;

@RestController
public class HelloResource {
	
	@Autowired
	private AuthenticationManager authmgr;
	
	@Autowired
	public MyUserDteatilService userDetailService;
	
	@Autowired
	private JWTUtil jwtutil;
	@GetMapping("/hello")
	public String hellio() {
		return "Hello WOrld";
	}
	@PostMapping("/authenticate")
	public ResponseEntity<?> auth(@RequestBody AuthenticationRequest req) {
		authmgr.authenticate(new UsernamePasswordAuthenticationToken(req.getUsername(),req.getPassword()));
		final UserDetails userDetail=userDetailService.loadUserByUsername(req.getUsername());
		
		final String jwt=jwtutil.generateToken(userDetail);
		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}
}